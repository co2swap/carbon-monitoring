weights = {
    'emissions': 1.5,
    'cost': 1.0,
    'compliance': 2.0,
    'renewable': 1.2
}
